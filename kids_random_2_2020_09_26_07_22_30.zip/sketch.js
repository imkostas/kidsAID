let x,y;
function setup() {
  createCanvas(400, 400);
  //frameRate(10);
  x=width/2;
  y=height/2;
}

function draw() {
  background(220);
  x += random(-5,5);
  y += random(-5,5);
  rect(x,y, 20,20);
}

function mousePressed(){
  x = mouseX;
  y = mouseY;
}